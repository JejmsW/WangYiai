//
//  NavigationController.h
//  Luzhou reading non - network technology co. LTD.
//
//  Created by jejms on 2018/2/26.
//  Copyright © 2018年 泸州阅非网络科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationController : UINavigationController
@property(nonatomic,assign) NSString *seleIndex;//前一个控制器标识
@end

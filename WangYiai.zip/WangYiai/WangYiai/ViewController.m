//
//  ViewController.m
//  WangYiai
//
//  Created by Jejms on 2019/12/8.
//  Copyright © 2019 Jejms. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end

//
//  TabBar.m
//  Luzhou reading non - network technology co. LTD.
//
//  Created by jejms on 2018/2/26.
//  Copyright © 2018年 泸州阅非网络科技有限公司. All rights reserved.
//

#import "TabBar.h"

@implementation TabBar

#pragma mark - Intial
- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
      
    }
    return self;
}

@end

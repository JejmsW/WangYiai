//
//  TabBarController.h
//  Luzhou reading non - network technology co. LTD.
//
//  Created by jejms on 2018/2/26.
//  Copyright © 2018年 泸州阅非网络科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabBarController : UITabBarController
@property(nonatomic,strong) UIWindow *window;
@end

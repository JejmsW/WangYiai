//
//  ViewController.h
//  WangYiai
//
//  Created by Jejms on 2019/12/8.
//  Copyright © 2019 Jejms. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

